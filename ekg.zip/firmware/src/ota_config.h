#pragma once
// Set these before the initial USB flash. Use your existing 2.4 GHz Wi-Fi.
constexpr char OTA_WIFI_SSID[] = "TPLink 9300";
constexpr char OTA_WIFI_PASSWORD[] = "Doffen2014@";
// Keep this token unchanged in later builds, or pass the OLD token to the uploader.
// Shared by BLE mode-entry authorization and ArduinoOTA upload authentication.
constexpr char OTA_TOKEN[] = "a7bff03672349533";
